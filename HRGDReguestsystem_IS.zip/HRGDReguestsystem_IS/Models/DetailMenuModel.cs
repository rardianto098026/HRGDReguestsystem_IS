﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HRDDReguestsystem_IS.Models
{
    public class DetailMenuModel
    {
        public string No { get; set; }
        public string ID_Employee { get; set; }
        public string Name { get; set; }
        public string Entity { get; set; }
        public string Role { get; set; }
        public string Menu { get; set; }
    }
}